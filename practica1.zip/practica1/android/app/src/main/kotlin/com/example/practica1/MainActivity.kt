package com.example.practica1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
